<?php

// Its cold and quiet over here..